// complete the implementation of triple and map such that
// [0,3,6,9,12] is printed

var arr = [0,1,2,3,4];

var triple = function() {};

Array.prototype.map = function() {};

var newArr = arr.map(triple);
console.log(newArr);
